
package com.veterinariasm.reserva.service;

import com.veterinariasm.reserva.dto.ReservaRequest;
import com.veterinariasm.reserva.dto.ReservaActualizarRequest;
import com.veterinariasm.reserva.dto.ServicioResponse;
import com.veterinariasm.reserva.model.Reserva;
import com.veterinariasm.reserva.model.DetalleReserva;
import com.veterinariasm.reserva.repository.ReservaRepository;
import com.veterinariasm.reserva.repository.DetalleReservaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final DetalleReservaRepository detalleReservaRepository;
    private final ServicioClient servicioClient;

    public ReservaService(
            ReservaRepository reservaRepository,
            DetalleReservaRepository detalleReservaRepository,
            ServicioClient servicioClient) {

        this.reservaRepository = reservaRepository;
        this.detalleReservaRepository = detalleReservaRepository;
        this.servicioClient = servicioClient;
    }

    public List<Reserva> listarReservas() {
        return reservaRepository.findAll();
    }

    public Reserva buscarPorId(Long id) {
        return reservaRepository.findById(id)
                .orElse(null);
    }

    public List<Reserva> listarPorUsuario(Long idUsuario) {
        return reservaRepository.findByIdUsuario(idUsuario);
    }

    @Transactional
    public Reserva crearReserva(ReservaRequest request) {

        if (request.getServicios() == null || request.getServicios().isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Debe seleccionar al menos un servicio");
        }

        BigDecimal total = BigDecimal.ZERO;
        List<DetalleReserva> detalles = new ArrayList<>();

        for (ReservaRequest.DetalleRequest item : request.getServicios()) {

            ServicioResponse servicio = servicioClient.buscarServicio(item.getIdServicio());

            if (servicio == null || !Boolean.TRUE.equals(servicio.getEstado())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "El servicio no está disponible");
            }

            total = total.add(servicio.getPrecio());

            DetalleReserva detalle = new DetalleReserva();
            detalle.setIdServicio(servicio.getIdServicio());
            detalle.setPrecio(servicio.getPrecio());

            detalles.add(detalle);
        }

        Reserva reserva = new Reserva();

        reserva.setIdUsuario(request.getIdUsuario());
        reserva.setNombreMascota(request.getNombreMascota());
        reserva.setFecha(request.getFecha());
        reserva.setHora(request.getHora());
        reserva.setTotal(total);
        reserva.setEstado("PENDIENTE");

        Reserva reservaGuardada = reservaRepository.save(reserva);

        for (DetalleReserva detalle : detalles) {
            detalle.setIdReserva(reservaGuardada.getIdReserva());
        }

        detalleReservaRepository.saveAll(detalles);

        return reservaGuardada;
    }

    @Transactional
    public Reserva actualizarReserva(Long id, ReservaActualizarRequest request) {

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "No se encontró la reserva"));

        if (request.getFecha() == null || request.getHora() == null ||
                request.getEstado() == null || request.getEstado().trim().isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Fecha, hora y estado son obligatorios");
        }

        String estado = request.getEstado().trim().toUpperCase();

        if (!estado.equals("PENDIENTE") &&
                !estado.equals("CONFIRMADA") &&
                !estado.equals("CANCELADA")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "El estado debe ser PENDIENTE, CONFIRMADA o CANCELADA");
        }

        reserva.setFecha(request.getFecha());
        reserva.setHora(request.getHora());
        reserva.setEstado(estado);

        return reservaRepository.save(reserva);
    }
}
