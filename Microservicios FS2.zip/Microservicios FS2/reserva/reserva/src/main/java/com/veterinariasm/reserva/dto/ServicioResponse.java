package com.veterinariasm.reserva.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ServicioResponse {

    private Long idServicio;
    private String nombre;
    private String categoria;
    private BigDecimal precio;
    private Boolean estado;
}
