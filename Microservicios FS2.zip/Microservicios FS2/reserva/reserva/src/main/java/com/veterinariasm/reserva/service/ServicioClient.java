package com.veterinariasm.reserva.service;

import com.veterinariasm.reserva.dto.ServicioResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ServicioClient {

    private final RestTemplate restTemplate;

    @Value("${servicio.api.url}")
    private String servicioApiUrl;

    public ServicioClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ServicioResponse buscarServicio(Long id) {

        String url = servicioApiUrl + "/api/servicios/" + id;

        return restTemplate.getForObject(url, ServicioResponse.class);
    }
}
