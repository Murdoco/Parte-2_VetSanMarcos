package com.veterinariasm.reserva.dto;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
public class ReservaRequest {

    private Long idUsuario;
    private String nombreMascota;
    private LocalDate fecha;
    private LocalTime hora;
    private List<DetalleRequest> servicios;

    @Getter
    @Setter
    public static class DetalleRequest {

        private Long idServicio;
    }
}
