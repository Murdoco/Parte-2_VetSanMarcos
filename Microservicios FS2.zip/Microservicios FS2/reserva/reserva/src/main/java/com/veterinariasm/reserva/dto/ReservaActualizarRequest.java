package com.veterinariasm.reserva.dto;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Setter
public class ReservaActualizarRequest {

    private LocalDate fecha;
    private LocalTime hora;
    private String estado;
}