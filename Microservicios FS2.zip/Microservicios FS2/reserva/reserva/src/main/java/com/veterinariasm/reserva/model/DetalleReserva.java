package com.veterinariasm.reserva.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "detalle_reserva")
public class DetalleReserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle")
    private Long idDetalle;

    @Column(name = "id_reserva", nullable = false)
    private Long idReserva;

    @Column(name = "id_servicio", nullable = false)
    private Long idServicio;

    @Column(nullable = false)
    private BigDecimal precio;
}
