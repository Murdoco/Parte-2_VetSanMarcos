package com.veterinariasm.reserva.repository;

import com.veterinariasm.reserva.model.DetalleReserva;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DetalleReservaRepository extends JpaRepository<DetalleReserva, Long> {

    List<DetalleReserva> findByIdReserva(Long idReserva);
}
