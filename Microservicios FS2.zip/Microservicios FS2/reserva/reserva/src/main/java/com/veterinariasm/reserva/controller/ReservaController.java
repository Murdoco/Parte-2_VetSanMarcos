
package com.veterinariasm.reserva.controller;

import com.veterinariasm.reserva.dto.ReservaRequest;
import com.veterinariasm.reserva.dto.ReservaActualizarRequest;
import com.veterinariasm.reserva.model.Reserva;
import com.veterinariasm.reserva.service.ReservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/reservas")
@CrossOrigin(origins = "http://localhost:5173")
@Tag(name = "Reservas", description = "Gestión de reservas veterinarias")
public class ReservaController {

    private final ReservaService reservaService;

    public ReservaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @GetMapping
    @Operation(summary = "Listar todas las reservas")
    public List<Reserva> listarReservas() {
        return reservaService.listarReservas();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar reserva por ID")
    public Reserva buscarPorId(@PathVariable Long id) {
        return reservaService.buscarPorId(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    @Operation(summary = "Listar reservas de un usuario")
    public List<Reserva> listarPorUsuario(@PathVariable Long idUsuario) {
        return reservaService.listarPorUsuario(idUsuario);
    }

    @PostMapping
    @Operation(summary = "Crear una reserva")
    public Reserva crearReserva(@RequestBody ReservaRequest request) {
        return reservaService.crearReserva(request);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una reserva")
    public Reserva actualizarReserva(
            @PathVariable Long id,
            @RequestBody ReservaActualizarRequest request) {
        return reservaService.actualizarReserva(id, request);
    }
}
