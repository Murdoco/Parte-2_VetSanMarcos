
package com.veterinariasm.usuario.service;

import com.veterinariasm.usuario.model.Usuario;
import com.veterinariasm.usuario.repository.UsuarioRepository;
import com.veterinariasm.usuario.dto.AuthResponse;
import com.veterinariasm.usuario.dto.LoginRequest;
import com.veterinariasm.usuario.security.JwtService;

import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public UsuarioService(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService) {

        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }

    // Registro público: siempre crea usuarios CLIENTE
    public Usuario registrarUsuario(Usuario usuario) {

        if (usuarioRepository.existsByCorreo(usuario.getCorreo())) {
            throw new RuntimeException("El correo ya está registrado");
        }

        usuario.setRol("CLIENTE");

        usuario.setContrasena(
                passwordEncoder.encode(usuario.getContrasena())
        );

        return usuarioRepository.save(usuario);
    }

    // Registro desde el panel administrativo
    public Usuario registrarUsuarioAdmin(Usuario usuario) {

        if (usuarioRepository.existsByCorreo(usuario.getCorreo())) {
            throw new RuntimeException("El correo ya está registrado");
        }

        String rol = usuario.getRol().toUpperCase().trim();

        if (!rol.equals("CLIENTE") && !rol.equals("ADMIN")) {
            throw new RuntimeException("El rol debe ser CLIENTE o ADMIN");
        }

        usuario.setRol(rol);

        usuario.setContrasena(
                passwordEncoder.encode(usuario.getContrasena())
        );

        return usuarioRepository.save(usuario);
    }

    // Actualizar usuario sin modificar su contraseña
    public Usuario actualizarUsuario(Long id, Usuario datos) {

        Usuario usuario = buscarPorId(id);

        if (usuarioRepository.existsByCorreo(datos.getCorreo())
                && !usuario.getCorreo().equalsIgnoreCase(datos.getCorreo())) {
            throw new RuntimeException("El correo ya está registrado");
        }

        String rol = datos.getRol().toUpperCase().trim();

        if (!rol.equals("CLIENTE") && !rol.equals("ADMIN")) {
            throw new RuntimeException("El rol debe ser CLIENTE o ADMIN");
        }

        usuario.setNombre(datos.getNombre());
        usuario.setCorreo(datos.getCorreo());
        usuario.setTelefono(datos.getTelefono());
        usuario.setRol(rol);

        return usuarioRepository.save(usuario);
    }

    // Eliminar usuario
    public void eliminarUsuario(Long id) {

        Usuario usuario = buscarPorId(id);

        usuarioRepository.delete(usuario);
    }

    public AuthResponse iniciarSesion(LoginRequest request) {

        Usuario usuario = usuarioRepository
                .findByCorreo(request.getCorreo())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (!passwordEncoder.matches(
                request.getContrasena(),
                usuario.getContrasena())) {

            throw new RuntimeException("Contraseña incorrecta");
        }

        String token = jwtService.generarToken(
                usuario.getCorreo(),
                usuario.getRol()
        );

        return new AuthResponse(
                token,
                usuario.getIdUsuario(),
                usuario.getCorreo(),
                usuario.getRol()
        );
    }
}
