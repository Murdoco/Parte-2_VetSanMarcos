package com.veterinariasm.usuario.controller;

import com.veterinariasm.usuario.model.Usuario;
import com.veterinariasm.usuario.service.UsuarioService;
import com.veterinariasm.usuario.dto.UsuarioResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "http://localhost:5173")
@Tag(name = "Usuarios", description = "Gestión de usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    private UsuarioResponse convertirRespuesta(Usuario usuario) {
        return new UsuarioResponse(
                usuario.getIdUsuario(),
                usuario.getNombre(),
                usuario.getCorreo(),
                usuario.getTelefono(),
                usuario.getRol()
        );
    }

    @GetMapping
    @Operation(summary = "Listar usuarios")
    public List<UsuarioResponse> listarUsuarios() {
        return usuarioService.listarUsuarios()
                .stream()
                .map(this::convertirRespuesta)
                .toList();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar usuario por ID")
    public UsuarioResponse buscarPorId(@PathVariable Long id) {
        return convertirRespuesta(usuarioService.buscarPorId(id));
    }

    @PostMapping
    @Operation(summary = "Registrar un usuario")
    public UsuarioResponse registrarUsuario(@RequestBody Usuario usuario) {
        return convertirRespuesta(usuarioService.registrarUsuario(usuario));
    }

    @PostMapping("/admin")
    @Operation(summary = "Crear usuario desde administración")
    public UsuarioResponse registrarUsuarioAdmin(@RequestBody Usuario usuario) {
        return convertirRespuesta(usuarioService.registrarUsuarioAdmin(usuario));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar usuario")
    public UsuarioResponse actualizarUsuario(
            @PathVariable Long id,
            @RequestBody Usuario usuario) {

        return convertirRespuesta(
                usuarioService.actualizarUsuario(id, usuario)
        );
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar usuario")
    public void eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuario(id);
    }
}
