package com.veterinariasm.usuario.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class AuthResponse {

    private String token;
    private Long idUsuario;
    private String correo;
    private String rol;

}