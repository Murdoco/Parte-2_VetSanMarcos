package com.veterinariasm.usuario.controller;

import com.veterinariasm.usuario.dto.LoginRequest;
import com.veterinariasm.usuario.dto.AuthResponse;
import com.veterinariasm.usuario.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
@Tag(name = "Autenticación", description = "Inicio de sesión de usuarios")
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/login")
    @Operation(summary = "Iniciar sesión y obtener token JWT")
    public AuthResponse iniciarSesion(@RequestBody LoginRequest request) {
        return usuarioService.iniciarSesion(request);
    }
}
