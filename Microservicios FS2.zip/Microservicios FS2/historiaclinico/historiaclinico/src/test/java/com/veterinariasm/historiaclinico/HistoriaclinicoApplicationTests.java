package com.veterinariasm.historiaclinico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistoriaclinicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
