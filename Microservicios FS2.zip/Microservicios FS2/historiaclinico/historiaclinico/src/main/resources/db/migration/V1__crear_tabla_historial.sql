CREATE TABLE historial_clinico (
    id_historial BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_usuario BIGINT NOT NULL,
    nombre_mascota VARCHAR(100) NOT NULL,
    fecha DATE NOT NULL,
    motivo_consulta VARCHAR(255) NOT NULL,
    diagnostico TEXT,
    tratamiento TEXT,
    observaciones TEXT
);