ALTER TABLE historial_clinico
ADD COLUMN id_reserva BIGINT;