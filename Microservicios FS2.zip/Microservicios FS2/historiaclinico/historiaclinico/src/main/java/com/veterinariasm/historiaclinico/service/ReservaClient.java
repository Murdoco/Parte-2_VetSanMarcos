package com.veterinariasm.historiaclinico.service;

import com.veterinariasm.historiaclinico.dto.ReservaResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ReservaClient {

    private final RestTemplate restTemplate;

    @Value("${reserva.api.url}")
    private String reservaApiUrl;

    public ReservaClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ReservaResponse buscarReserva(Long id) {

        String url = reservaApiUrl + "/api/reservas/" + id;

        return restTemplate.getForObject(url, ReservaResponse.class);
    }
}