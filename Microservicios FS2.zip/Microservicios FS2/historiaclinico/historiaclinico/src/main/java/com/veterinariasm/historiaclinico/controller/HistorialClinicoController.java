package com.veterinariasm.historiaclinico.controller;

import com.veterinariasm.historiaclinico.model.HistorialClinico;
import com.veterinariasm.historiaclinico.service.HistorialClinicoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/historiales")
@CrossOrigin(origins = "http://localhost:5173")
@Tag(name = "Historial clínico", description = "Gestión de historiales clínicos de mascotas")
public class HistorialClinicoController {

    private final HistorialClinicoService historialService;

    public HistorialClinicoController(HistorialClinicoService historialService) {
        this.historialService = historialService;
    }

    @GetMapping
    @Operation(summary = "Listar todos los historiales clínicos")
    public List<HistorialClinico> listarHistoriales() {
        return historialService.listarHistoriales();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar historial clínico por ID")
    public HistorialClinico buscarPorId(@PathVariable Long id) {
        return historialService.buscarPorId(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    @Operation(summary = "Listar historiales de un usuario")
    public List<HistorialClinico> listarPorUsuario(@PathVariable Long idUsuario) {
        return historialService.listarPorUsuario(idUsuario);
    }

    @GetMapping("/mascota/{nombreMascota}")
    @Operation(summary = "Listar historiales por nombre de mascota")
    public List<HistorialClinico> listarPorMascota(@PathVariable String nombreMascota) {
        return historialService.listarPorMascota(nombreMascota);
    }

    @PostMapping
    @Operation(summary = "Registrar un historial clínico")
    public HistorialClinico guardarHistorial(@RequestBody HistorialClinico historial) {
        return historialService.guardarHistorial(historial);
    }
}
