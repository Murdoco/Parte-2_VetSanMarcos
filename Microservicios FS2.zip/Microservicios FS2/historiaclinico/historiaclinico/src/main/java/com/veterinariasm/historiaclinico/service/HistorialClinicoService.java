package com.veterinariasm.historiaclinico.service;

import com.veterinariasm.historiaclinico.model.HistorialClinico;
import com.veterinariasm.historiaclinico.repository.HistorialClinicoRepository;
import com.veterinariasm.historiaclinico.dto.ReservaResponse;

import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.client.RestClientException;
import org.springframework.http.HttpStatus;

import java.util.List;

@Service
public class HistorialClinicoService {

    private final HistorialClinicoRepository historialRepository;
    private final ReservaClient reservaClient;

    public HistorialClinicoService(
            HistorialClinicoRepository historialRepository,
            ReservaClient reservaClient) {

        this.historialRepository = historialRepository;
        this.reservaClient = reservaClient;
    }

    public List<HistorialClinico> listarHistoriales() {
        return historialRepository.findAll();
    }

    public HistorialClinico buscarPorId(Long id) {
        return historialRepository.findById(id)
                .orElse(null);
    }

    public List<HistorialClinico> listarPorUsuario(Long idUsuario) {
        return historialRepository.findByIdUsuario(idUsuario);
    }

    public List<HistorialClinico> listarPorMascota(String nombreMascota) {
        return historialRepository.findByNombreMascota(nombreMascota);
    }

    public HistorialClinico guardarHistorial(HistorialClinico historial) {

        if (historial.getIdReserva() != null) {

            ReservaResponse reserva;

            try {
                reserva = reservaClient.buscarReserva(historial.getIdReserva());
            } catch (RestClientException e) {
                throw new ResponseStatusException(
                        HttpStatus.SERVICE_UNAVAILABLE,
                        "No se pudo consultar el microservicio de reservas");
            }

            if (reserva == null) {
                throw new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "La reserva no existe");
            }

            if (!reserva.getIdUsuario().equals(historial.getIdUsuario())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "La reserva no pertenece a este usuario");
            }

            if (!reserva.getNombreMascota().trim()
                    .equalsIgnoreCase(historial.getNombreMascota().trim())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "La mascota no coincide con la reserva");
            }
        }

        return historialRepository.save(historial);
    }
}
