package com.veterinariasm.historiaclinico.repository;

import com.veterinariasm.historiaclinico.model.HistorialClinico;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface HistorialClinicoRepository extends JpaRepository<HistorialClinico, Long> {

    List<HistorialClinico> findByIdUsuario(Long idUsuario);

    List<HistorialClinico> findByNombreMascota(String nombreMascota);

}
