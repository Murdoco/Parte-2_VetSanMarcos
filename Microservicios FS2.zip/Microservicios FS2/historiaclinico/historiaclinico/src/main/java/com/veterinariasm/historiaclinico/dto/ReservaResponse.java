package com.veterinariasm.historiaclinico.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReservaResponse {

    private Long idReserva;
    private Long idUsuario;
    private String nombreMascota;

}