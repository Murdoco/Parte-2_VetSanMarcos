package com.veterinariasm.historiaclinico.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "historial_clinico")
public class HistorialClinico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historial")
    private Long idHistorial;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "id_reserva")
    private Long idReserva;

    @Column(name = "nombre_mascota", nullable = false)
    private String nombreMascota;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(name = "motivo_consulta", nullable = false)
    private String motivoConsulta;

    private String diagnostico;

    private String tratamiento;

    private String observaciones;
}
