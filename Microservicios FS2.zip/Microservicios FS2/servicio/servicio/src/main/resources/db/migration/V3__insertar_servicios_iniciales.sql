INSERT INTO servicios (nombre, categoria, precio, estado) VALUES
-- CONSULTAS
('Consulta general', 'Consultas', 15000, TRUE),
('Consulta urgencia', 'Consultas', 20000, TRUE),
('Control postoperatorio', 'Consultas', 10000, TRUE),
('Consulta ave / conejo', 'Consultas', 18000, TRUE),
('Segunda opinión médica', 'Consultas', 20000, TRUE),

-- EXÁMENES
('Hemograma completo', 'Exámenes', 22000, TRUE),
('Perfil bioquímico completo', 'Exámenes', 35000, TRUE),
('Radiografía (1 proyección)', 'Exámenes', 28000, TRUE),
('Ecografía abdominal', 'Exámenes', 45000, TRUE),
('Test de leishmaniasis', 'Exámenes', 18000, TRUE),

-- CIRUGÍAS
('Esterilización hembra canina', 'Cirugías', 80000, TRUE),
('Esterilización macho canino', 'Cirugías', 60000, TRUE),
('Esterilización hembra felina', 'Cirugías', 65000, TRUE),
('Esterilización macho felino', 'Cirugías', 50000, TRUE),
('Extirpación de tumor cutáneo', 'Cirugías', 120000, TRUE),
('Cesárea de urgencia', 'Cirugías', 180000, TRUE),

-- DESPARASITACIONES
('Desparasitación interna pequeños', 'Desparasitaciones', 8000, TRUE),
('Desparasitación interna medianos', 'Desparasitaciones', 9500, TRUE),
('Desparasitación interna grandes', 'Desparasitaciones', 11000, TRUE),
('Desparasitación interna felina', 'Desparasitaciones', 8000, TRUE),
('Antiparasitario externo (pipeta)', 'Desparasitaciones', 7500, TRUE),

-- VACUNACIÓN
('Vacuna antirrábica canina', 'Vacunación', 12000, TRUE),
('Vacuna séxtuple canina', 'Vacunación', 18000, TRUE),
('Vacuna bivalente felina', 'Vacunación', 15000, TRUE),
('Vacuna triple felina', 'Vacunación', 17000, TRUE),
('Vacuna Bordetella canina', 'Vacunación', 14000, TRUE),
('Vacuna antirrábica felina', 'Vacunación', 12000, TRUE),

-- OTROS
('Corte de uñas', 'Otros', 5000, TRUE),
('Limpieza dental', 'Otros', 55000, TRUE),
('Microchip identificación', 'Otros', 15000, TRUE),
('Hospitalización (por día)', 'Otros', 30000, TRUE);
