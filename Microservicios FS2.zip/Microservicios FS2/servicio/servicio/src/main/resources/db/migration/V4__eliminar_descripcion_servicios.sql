ALTER TABLE servicios
DROP COLUMN descripcion;