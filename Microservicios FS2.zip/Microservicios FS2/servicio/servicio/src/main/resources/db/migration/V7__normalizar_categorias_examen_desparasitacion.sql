UPDATE servicios
SET categoria = 'Examen'
WHERE categoria = 'Exámenes';

UPDATE servicios
SET categoria = 'Desparasitación'
WHERE categoria = 'Desparasitaciones';
