UPDATE servicios
SET categoria = 'Consulta'
WHERE categoria = 'consultas';

UPDATE servicios
SET categoria = 'Examen'
WHERE categoria = 'examentes';

UPDATE servicios
SET categoria = 'Cirugía'
WHERE categoria = 'cirugias';

UPDATE servicios
SET categoria = 'Desparasitación'
WHERE categoria = 'desparacitaciones';

UPDATE servicios
SET categoria = 'Vacunación'
WHERE categoria = 'vacunacion';

UPDATE servicios
SET categoria = 'Otros'
WHERE categoria = 'otros';
