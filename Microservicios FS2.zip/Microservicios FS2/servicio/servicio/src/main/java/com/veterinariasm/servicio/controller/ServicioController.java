package com.veterinariasm.servicio.controller;

import com.veterinariasm.servicio.model.Servicio;
import com.veterinariasm.servicio.service.ServicioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/servicios")
@CrossOrigin(origins = "http://localhost:5173")
@Tag(name = "Servicios", description = "Gestión de servicios veterinarios")
public class ServicioController {

    private final ServicioService servicioService;

    public ServicioController(ServicioService servicioService) {
        this.servicioService = servicioService;
    }

    @GetMapping
    @Operation(summary = "Listar todos los servicios")
    public List<Servicio> listarServicios() {
        return servicioService.listarServicios();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar servicio por ID")
    public Servicio buscarPorId(@PathVariable Long id) {
        return servicioService.buscarPorId(id);
    }

    @PostMapping
    @Operation(summary = "Registrar un servicio")
    public Servicio guardarServicio(@Valid @RequestBody Servicio servicio) {
        return servicioService.guardarServicio(servicio);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un servicio")
    public void eliminarServicio(@PathVariable Long id) {
        servicioService.eliminarServicio(id);
    }

    @GetMapping("/activos")
    @Operation(summary = "Listar servicios activos")
    public List<Servicio> listarServiciosActivos() {
        return servicioService.listarServiciosActivos();
    }

    @PatchMapping("/{id}/estado")
    @Operation(summary = "Cambiar estado de un servicio")
    public Servicio cambiarEstado(
            @PathVariable Long id,
            @RequestParam Boolean estado) {

        return servicioService.cambiarEstado(id, estado);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un servicio")
    public Servicio actualizarServicio(
            @PathVariable Long id,
            @Valid @RequestBody Servicio servicio) {

        return servicioService.actualizarServicio(id, servicio);
    }
}
