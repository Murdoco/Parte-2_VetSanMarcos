package com.veterinariasm.servicio.service;

import com.veterinariasm.servicio.model.Servicio;
import com.veterinariasm.servicio.repository.ServicioRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;

@Service
public class ServicioService {

    private final ServicioRepository servicioRepository;

    public ServicioService(ServicioRepository servicioRepository) {
        this.servicioRepository = servicioRepository;
    }

    public List<Servicio> listarServicios() {
        return servicioRepository.findAll();
    }

    public Servicio buscarPorId(Long id) {
        return servicioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Servicio no encontrado"));
    }

    public Servicio guardarServicio(Servicio servicio) {
        return servicioRepository.save(servicio);
    }

    public void eliminarServicio(Long id) {
        if (!servicioRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Servicio no encontrado");
        }

        servicioRepository.deleteById(id);
    }

    public List<Servicio> listarServiciosActivos() {
        return servicioRepository.findByEstadoTrue();
    }

    public Servicio cambiarEstado(Long id, Boolean estado) {
        Servicio servicio = buscarPorId(id);

        servicio.setEstado(estado);

        return servicioRepository.save(servicio);
    }

    public Servicio actualizarServicio(Long id, Servicio datosActualizados) {
        Servicio servicio = buscarPorId(id);

        servicio.setNombre(datosActualizados.getNombre());
        servicio.setDescripcion(datosActualizados.getDescripcion());
        servicio.setCategoria(datosActualizados.getCategoria());
        servicio.setPrecio(datosActualizados.getPrecio());

        return servicioRepository.save(servicio);
    }
}
