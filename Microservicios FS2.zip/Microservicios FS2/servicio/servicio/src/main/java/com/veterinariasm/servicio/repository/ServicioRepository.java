package com.veterinariasm.servicio.repository;

import com.veterinariasm.servicio.model.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ServicioRepository extends JpaRepository<Servicio, Long> {

    List<Servicio> findByEstadoTrue();

}
